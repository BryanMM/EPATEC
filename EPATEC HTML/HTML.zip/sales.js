var app = angular.module('sales', ['ngRoute']);

app.controller('salesFormCtrl', function ($scope, $http) {

      
      
      console.log('click');
    $scope.addClient=function(){
        console.log('click2');
         var data = $.param({
                    P_ID: $scope.name,
                    Price: $scope.phone,
                    Excent: $scope.priority,
                    PDrescription:$scope.status,
                    Quantity: $scope.status


                });
      console.info(data);
      var config = {
                    headers : {
                        'Content-Type': 'application/json;'
                    }
                }

     $http.post('isaac:7549/api/product/post/', data, config)
        .success(function (data, status, headers, config) {
                    $scope.PostDataResponse = data;
                })
         .error(function (data, status, header, config) {
                    $scope.ResponseDetails = "Data: " + data +
                        "<hr />status: " + status +
                        "<hr />headers: " + header +
                        "<hr />config: " + config;
                });
        
    }
     
            });


